package com.mts.model;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class MovieDAO {

    public boolean addMovie(String movieId, String movieTitle, String movieDescription, double moviePrice, String movieDate, String movieTime, InputStream moviePoster) throws SQLException {
        String query = "INSERT INTO movie (M_ID, M_NAME, M_DESC, M_PRICE, M_DATE, M_TIME, M_POSTER) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, movieId);
            pstmt.setString(2, movieTitle);
            pstmt.setString(3, movieDescription);
            pstmt.setDouble(4, moviePrice);
            pstmt.setDate(5, java.sql.Date.valueOf(movieDate));
            pstmt.setString(6, movieTime);
            pstmt.setBlob(7, moviePoster);

            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean updateSeats(String movieId, String seatType, int seatAmount) throws SQLException {
        String query = "UPDATE movie SET M_SEATTYPE = ?, M_SEATAMOUNT = ? WHERE M_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, seatType);
            pstmt.setInt(2, seatAmount);
            pstmt.setString(3, movieId);
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean updateMovie(String movieId, String movieTitle, String movieDescription, double moviePrice, String movieDate, String movieTime) throws SQLException {
        String query = "UPDATE movie SET M_NAME = ?, M_DESC = ?, M_PRICE = ?, M_DATE = ?, M_TIME = ? WHERE M_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, movieTitle);
            pstmt.setString(2, movieDescription);
            pstmt.setDouble(3, moviePrice);
            pstmt.setDate(4, java.sql.Date.valueOf(movieDate));
            pstmt.setString(5, movieTime);
            pstmt.setString(6, movieId);
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean deleteMovie(String movieId) throws SQLException {
        String query = "DELETE FROM movie WHERE M_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, movieId);
            return pstmt.executeUpdate() > 0;
        }
    }

    public int getTotalMovies() throws SQLException {
        String query = "SELECT COUNT(*) AS total FROM movie";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("total");
            }
        }
        return 0; 
    }

    public int getTotalSeatsAvailable() throws SQLException {
        String query = "SELECT SUM(M_SEATAMOUNT) AS totalSeats FROM movie";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("totalSeats");
            }
        }
        return 0; 
    }

    public List<String> getAllMovieIds() throws SQLException {
        List<String> movieIds = new ArrayList<>();
        String query = "SELECT M_ID FROM movie";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                movieIds.add(rs.getString("M_ID"));
            }
        }

        return movieIds;
    }

    public List<String> getAllMovieNames() throws SQLException {
        List<String> movieNames = new ArrayList<>();
        String query = "SELECT M_NAME FROM movie";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                movieNames.add(rs.getString("M_NAME"));
            }
        }

        return movieNames;
    }
    
    public List<String> getMoviePostersBase64() throws SQLException {
        List<String> postersBase64 = new ArrayList<>();
        String query = "SELECT M_POSTER FROM movie";

        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Blob blob = rs.getBlob("M_POSTER");
                if (blob != null) {
                    byte[] imgBytes = blob.getBytes(1, (int) blob.length());
                    String base64Image = Base64.getEncoder().encodeToString(imgBytes);
                    postersBase64.add(base64Image);
                }
            }
        }

        return postersBase64;
    }
    
    public List<String> getNewestMovieNames(int limit) throws SQLException {
        List<String> newestMovieNames = new ArrayList<>();
        String query = "SELECT M_NAME FROM movie ORDER BY M_DATE DESC FETCH FIRST ? ROWS ONLY";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
        
            pstmt.setInt(1, limit);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                newestMovieNames.add(rs.getString("M_NAME"));
            }
        }

        return newestMovieNames;
    }
}
