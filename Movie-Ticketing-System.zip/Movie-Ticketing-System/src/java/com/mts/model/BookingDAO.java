package com.mts.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BookingDAO {
    private static final Logger LOGGER = Logger.getLogger(BookingDAO.class.getName());

    public boolean bookMovie(String bookingId, String movieName, String seatType, int numSeats, String foodName) throws SQLException {
        String movieId = getMovieIdByName(movieName);
        String foodId = getFoodIdByName(foodName);

        if (movieId == null) {
            throw new SQLException("Movie not found");
        }

        String query = "INSERT INTO booking (B_ID, B_SEAT, B_SEATTYPE, M_ID, F_ID) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, bookingId);
            pstmt.setInt(2, numSeats);
            pstmt.setString(3, seatType);
            pstmt.setString(4, movieId);
            pstmt.setString(5, foodId);

            return pstmt.executeUpdate() > 0;
        }
    }

    private String getMovieIdByName(String movieName) throws SQLException {
        String query = "SELECT M_ID FROM movie WHERE M_NAME = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, movieName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("M_ID");
                }
            }
        }
        return null;
    }

    private String getFoodIdByName(String foodName) throws SQLException {
        if (foodName == null || foodName.isEmpty()) {
            return null;
        }
        String query = "SELECT F_ID FROM f_addon WHERE F_NAME = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, foodName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("F_ID");
                }
            }
        }
        return null;
    }
    
    public void deleteBooking(String bookingId) throws SQLException {
        String query = "DELETE FROM booking WHERE B_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, bookingId);
            pstmt.executeUpdate();
        }
    }

    public void deleteBill(String billId) throws SQLException {
        String query = "DELETE FROM bill WHERE B_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, billId);
            pstmt.executeUpdate();
        }
    }    
}
