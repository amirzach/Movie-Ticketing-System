package com.mts.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BillDAO {

    public double calculateTotalPrice(String movieName, String seatType, int numSeats, String foodName) throws SQLException {
        double moviePrice = getMoviePriceByName(movieName);
        double seatPrice = getSeatPriceByType(seatType);
        double foodPrice = getFoodPriceByName(foodName);

        return (moviePrice + seatPrice) * numSeats + foodPrice;
    }

    public void insertBill(String billId, String customerId, double totalPrice, String movieId, String bookingId) throws SQLException {
        String query = "INSERT INTO BILL (B_ID, C_ID, B_TOTAL, M_ID, BOOKING_ID) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, billId);
            preparedStatement.setString(2, customerId);
            preparedStatement.setDouble(3, totalPrice);
            preparedStatement.setString(4, movieId);
            preparedStatement.setString(5, bookingId);
            preparedStatement.executeUpdate();
        }
    }

    public String getMovieIdByName(String movieName) throws SQLException {
        String query = "SELECT M_ID FROM MOVIE WHERE M_NAME = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, movieName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("M_ID");
                }
            }
        }
        return null;
    }

    private double getMoviePriceByName(String movieName) throws SQLException {
        String query = "SELECT M_PRICE FROM MOVIE WHERE M_NAME = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, movieName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("M_PRICE");
                }
            }
        }
        return 0.0;
    }

    private double getSeatPriceByType(String seatType) {
        switch (seatType.toLowerCase()) {
            case "premium":
                return 30.0;
            case "vip":
                return 50.0;
            default:
                return 20.0;
        }
    }

    private double getFoodPriceByName(String foodName) throws SQLException {
        if (foodName == null || foodName.isEmpty()) {
            return 0.0;
        }
        String query = "SELECT F_PRICE FROM F_ADDON WHERE F_NAME = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, foodName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("F_PRICE");
                }
            }
        }
        return 0.0;
    }
}
