package com.mts.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FoodDAO {

    public void addFoodAddon(String foodId, String foodName, String foodType, double foodPrice) throws SQLException {
        String query = "INSERT INTO F_ADDON (F_ID, F_NAME, F_TYPE, F_PRICE) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query))  {
            pstmt.setString(1, foodId);
            pstmt.setString(2, foodName);
            pstmt.setString(3, foodType);
            pstmt.setDouble(4, foodPrice);
            pstmt.executeUpdate();
        }
    }

    public void modifyFoodAddon(String foodId, String foodName, String foodType, double foodPrice) throws SQLException {
        String query = "UPDATE F_ADDON SET F_NAME = ?, F_TYPE = ?, F_PRICE = ? WHERE F_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, foodName);
            pstmt.setString(2, foodType);
            pstmt.setDouble(3, foodPrice);
            pstmt.setString(4, foodId);
            pstmt.executeUpdate();
        }
    }

    public void deleteFoodAddon(String foodId) throws SQLException {
        String query = "DELETE FROM F_ADDON WHERE F_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, foodId);
            pstmt.executeUpdate();
        }
    }

    public List<String> getAllFoodIds() throws SQLException {
        List<String> foodIds = new ArrayList<>();
        String query = "SELECT F_ID FROM F_ADDON";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                foodIds.add(rs.getString("F_ID"));
            }
        }

        return foodIds;
    }

    public List<String> getAllFoodNames() throws SQLException {
        List<String> foodNames = new ArrayList<>();
        String query = "SELECT F_NAME FROM F_ADDON";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                foodNames.add(rs.getString("F_NAME"));
            }
        }

        return foodNames;
    }
}
