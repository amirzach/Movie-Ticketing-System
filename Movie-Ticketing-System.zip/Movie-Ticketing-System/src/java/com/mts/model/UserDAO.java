package com.mts.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserDAO {
    private static final Logger LOGGER = Logger.getLogger(UserDAO.class.getName());

    public boolean validateUser(String username, String password) throws SQLException {
        String query = "SELECT C_ID FROM customer WHERE C_Name = ? AND C_Password = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    public String validateStaff(String staffId, String password) throws SQLException {
        String query = "SELECT S_ID FROM staff WHERE S_Id = ? AND S_Password = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, staffId);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("S_ID");
                } else {
                    return null;
                }
            }
        }
    }

    public boolean registerUser(String fullName, String email, String password) throws SQLException {
        String query = "INSERT INTO customer (C_ID, C_Name, C_Email, C_Password) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            String customerId = UUID.randomUUID().toString().substring(0, 10);
            pstmt.setString(1, customerId);
            pstmt.setString(2, fullName);
            pstmt.setString(3, email);
            pstmt.setString(4, password);
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean resetPassword(String email, String newPassword) throws SQLException {
        String checkQuery = "SELECT C_ID FROM customer WHERE C_Email = ?";
        String updateQuery = "UPDATE customer SET C_Password = ? WHERE C_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
            checkStmt.setString(1, email);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    String customerId = rs.getString("C_ID");
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                        updateStmt.setString(1, newPassword);
                        updateStmt.setString(2, customerId);
                        return updateStmt.executeUpdate() > 0;
                    }
                } else {
                    return false;
                }
            }
        }
    }

    public boolean isPasswordSameAsOld(String email, String newPassword) throws SQLException {
        String query = "SELECT C_Password FROM customer WHERE C_Email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String oldPassword = rs.getString("C_Password");
                    return oldPassword.equals(newPassword);
                } else {
                    return false;
                }
            }
        }
    }

    public boolean isUserExists(String email) throws SQLException {
        String query = "SELECT COUNT(*) FROM customer WHERE C_Email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        }
        return false;
    }

    public String getStaffNameById(String staffId) throws SQLException {
        String query = "SELECT S_NAME FROM staff WHERE S_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, staffId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("S_NAME");
                } else {
                    return null;  
                }
            }
        }
    }

    public String getUserName(String username) throws SQLException {
        String query = "SELECT C_Name FROM customer WHERE C_Name = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("C_Name");
                } else {
                    return null;
                }
            }
        }
    }
    
    public String getCustomerNameById(String customerId) throws SQLException {
        String query = "SELECT C_Name FROM customer WHERE C_ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, customerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("C_Name");
                } else {
                    return null;
                }
            }
        }
    }    
}
