package com.mts.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

public class PaymentDAO {

    public void insertPayment(String paymentId, String customerId, String cardNumber, String bankName) throws SQLException {
        String query = "INSERT INTO PAYMENTDETAILS (P_ID, C_ID, P_CARDNUM, P_BANK) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, paymentId);
            preparedStatement.setString(2, customerId);
            preparedStatement.setString(3, cardNumber);
            preparedStatement.setString(4, bankName);
            preparedStatement.executeUpdate();
        }
    }

    public String generatePaymentId() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append((char) ('A' + random.nextInt(26)));
        }
        return sb.toString();
    }
}
