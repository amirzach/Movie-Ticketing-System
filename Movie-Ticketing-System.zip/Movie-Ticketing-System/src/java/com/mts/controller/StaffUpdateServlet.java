package com.mts.controller;

import com.mts.model.MovieDAO;
import com.mts.model.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;

@MultipartConfig(maxFileSize = 1024 * 1024 * 5) // 5MB max size for uploaded files
public class StaffUpdateServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();
    private MovieDAO movieDAO = new MovieDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String staffId = (String) session.getAttribute("staffId");

        if (staffId == null) {
            response.sendRedirect("Login.jsp");
            return;
        }

        try {
            String staffName = userDAO.getStaffNameById(staffId);
            request.setAttribute("staffName", staffName);

            List<String> movieIds = movieDAO.getAllMovieIds();
            request.setAttribute("movieIds", movieIds);

            request.getRequestDispatcher("Staff_Update.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("modifySeats".equals(action)) {
            modifySeats(request, response);
        } else if ("deleteMovie".equals(action)) {
            deleteMovie(request, response);
        } else if ("addMovie".equals(action)) {
            addNewMovie(request, response);
        } else {
            response.sendRedirect("Staff_Update.jsp");
        }
    }

    private void addNewMovie(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movieId = request.getParameter("movie_id");
        String movieTitle = request.getParameter("movie_title");
        String movieDescription = request.getParameter("movie_description");
        double moviePrice = Double.parseDouble(request.getParameter("movie_price"));
        String movieDate = request.getParameter("movie_date");
        String movieTime = request.getParameter("movie_time");

        Part filePart = request.getPart("movie_poster");
        InputStream posterInputStream = null;
        if (filePart != null && filePart.getSize() > 0) {
            posterInputStream = filePart.getInputStream();
        }

        try {
            movieDAO.addMovie(movieId, movieTitle, movieDescription, moviePrice, movieDate, movieTime, posterInputStream);

            request.setAttribute("successMessage", "Movie added successfully.");
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Failed to add movie.");
            throw new ServletException(e);
        }

        response.sendRedirect("Staff_Update.jsp");
    }

    private void modifySeats(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movieId = request.getParameter("modify_movie_id");
        String seatType = request.getParameter("seat_type");
        int seatAmount = Integer.parseInt(request.getParameter("seat_amount"));

        try {
            movieDAO.updateSeats(movieId, seatType, seatAmount);

            request.setAttribute("successMessage", "Seats updated successfully.");
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Failed to update seats.");
            throw new ServletException(e);
        }

        response.sendRedirect("Staff_Update.jsp");
    }

    private void deleteMovie(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movieId = request.getParameter("delete_movie_id");

        try {
            movieDAO.deleteMovie(movieId);

            request.setAttribute("successMessage", "Movie deleted successfully.");
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Failed to delete movie.");
            throw new ServletException(e);
        }

        response.sendRedirect("Staff_Update.jsp");
    }
}
