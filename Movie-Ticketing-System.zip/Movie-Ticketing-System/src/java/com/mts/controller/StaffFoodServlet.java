package com.mts.controller;

import com.mts.model.FoodDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@MultipartConfig(maxFileSize = 1024 * 1024 * 5) 
public class StaffFoodServlet extends HttpServlet {
    private FoodDAO foodDAO = new FoodDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("addFoodAddon".equals(action)) {
            addFoodAddon(request, response);
        } else if ("modifyFoodAddon".equals(action)) {
            modifyFoodAddon(request, response);
        } else if ("deleteFoodAddon".equals(action)) {
            deleteFoodAddon(request, response);
        } else {
            response.sendRedirect("Staff_Food.jsp");
        }
    }

    private void addFoodAddon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String foodId = request.getParameter("food_id");
        String foodName = request.getParameter("food_name");
        String foodType = request.getParameter("food_type");
        double foodPrice = Double.parseDouble(request.getParameter("food_price"));

        try {
            foodDAO.addFoodAddon(foodId, foodName, foodType, foodPrice);
            request.setAttribute("successMessage", "Food addon added successfully.");
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Failed to add food addon.");
            throw new ServletException(e);
        }

        request.getRequestDispatcher("Staff_Food.jsp").forward(request, response);
    }

    private void modifyFoodAddon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String foodId = request.getParameter("food_id");
        String foodName = request.getParameter("food_name");
        String foodType = request.getParameter("food_type");
        double foodPrice = Double.parseDouble(request.getParameter("food_price"));

        try {
            foodDAO.modifyFoodAddon(foodId, foodName, foodType, foodPrice);
            request.setAttribute("successMessage", "Food addon modified successfully.");
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Failed to modify food addon.");
            throw new ServletException(e);
        }

        request.getRequestDispatcher("Staff_Food.jsp").forward(request, response);
    }

    private void deleteFoodAddon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String foodId = request.getParameter("food_id");

        try {
            foodDAO.deleteFoodAddon(foodId);
            request.setAttribute("successMessage", "Food addon deleted successfully.");
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Failed to delete food addon.");
            throw new ServletException(e);
        }

        request.getRequestDispatcher("Staff_Food.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String staffName = (String) session.getAttribute("staffName");

        if (staffName != null && !staffName.isEmpty()) {
            request.setAttribute("staffName", staffName);
        }

        request.getRequestDispatcher("Staff_Food.jsp").forward(request, response);
    }
}
