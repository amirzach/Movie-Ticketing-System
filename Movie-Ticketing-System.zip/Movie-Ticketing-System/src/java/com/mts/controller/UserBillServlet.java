package com.mts.controller;

import com.mts.model.BillDAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UserBillServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = Logger.getLogger(UserBillServlet.class.getName());

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/User_Bill.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userName = (String) session.getAttribute("userName");
        String movieName = (String) session.getAttribute("movieName");
        String seatType = (String) session.getAttribute("seatType");
        int numSeats = (int) session.getAttribute("numSeats");
        String foodName = (String) session.getAttribute("foodName");
        String bookingId = (String) session.getAttribute("bookingId");
        String customerId = (String) session.getAttribute("customerId");

        try {
            BillDAO billDAO = new BillDAO();
            double totalPrice = billDAO.calculateTotalPrice(movieName, seatType, numSeats, foodName);
            String billId = generateBillId();
            String movieId = billDAO.getMovieIdByName(movieName);

            if (movieId == null) {
                throw new SQLException("Movie ID not found for movie name: " + movieName);
            }

            billDAO.insertBill(billId, customerId, totalPrice, movieId, bookingId);

            request.setAttribute("billId", billId);
            request.setAttribute("bookingId", bookingId);
            request.setAttribute("customerName", userName);
            request.setAttribute("customerId", customerId);
            request.setAttribute("totalPrice", totalPrice);
            request.setAttribute("movieName", movieName);
            request.setAttribute("seatType", seatType);
            request.setAttribute("numSeats", numSeats);
            request.setAttribute("foodName", foodName);

            request.getRequestDispatcher("/User_Bill.jsp").forward(request, response);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database error", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error: " + e.getMessage());
        }
    }

    private String generateBillId() {
        Random random = new Random();
        int number = random.nextInt(999999);
        return String.format("B%06d", number);
    }
}
