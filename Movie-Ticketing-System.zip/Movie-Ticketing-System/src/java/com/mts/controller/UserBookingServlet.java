package com.mts.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.mts.model.BookingDAO;
import java.util.Random;

public class UserBookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = Logger.getLogger(UserBookingServlet.class.getName());

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userName = (String) session.getAttribute("userName");
        if (userName == null) {
            userName = "User";
        }
        request.setAttribute("userName", userName);

        request.getRequestDispatcher("/User_Booking.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String movieName = request.getParameter("movieName");
        String seatType = request.getParameter("seatType");
        int numSeats = Integer.parseInt(request.getParameter("numSeats"));
        String foodName = request.getParameter("foodName");

        String bookingId = generateBookingId();
        boolean success = false;

        try {
            BookingDAO bookingDAO = new BookingDAO();
            success = bookingDAO.bookMovie(bookingId, movieName, seatType, numSeats, foodName);

            if (success) {
                response.sendRedirect("User_Bill.jsp");
            } else {
                response.sendRedirect("User_Booking.jsp");
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL Exception", e);
            response.sendRedirect("User_Booking.jsp");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception", e);
            response.sendRedirect("User_Booking.jsp");
        }
    }

    private String generateBookingId() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder bookingId = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            bookingId.append(characters.charAt(random.nextInt(characters.length())));
        }
        return bookingId.toString();
    }
}
