package com.mts.controller;

import com.mts.model.UserDAO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class ResetPasswordServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String newPassword = request.getParameter("password");

        try {
            // Check if the new password is the same as the old password
            if (userDAO.isPasswordSameAsOld(email, newPassword)) {
                request.setAttribute("errorMessage", "Error: New password cannot be the same as the old password.");
                request.getRequestDispatcher("User_ResetPass.jsp").forward(request, response);
                return;
            }

            boolean isReset = userDAO.resetPassword(email, newPassword);
            if (isReset) {
                request.setAttribute("successMessage", "Password reset successful! Redirecting to login page...");
                response.setHeader("Refresh", "3; URL=Login.jsp");
            } else {
                request.setAttribute("errorMessage", "Error: Email not found. Please enter a valid email.");
                request.getRequestDispatcher("User_ResetPass.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
