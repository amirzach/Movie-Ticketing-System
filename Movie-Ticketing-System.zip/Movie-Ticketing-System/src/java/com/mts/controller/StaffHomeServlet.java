package com.mts.controller;

import com.mts.model.UserDAO;
import com.mts.model.MovieDAO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

public class StaffHomeServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();
    private MovieDAO movieDAO = new MovieDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String staffId = (String) session.getAttribute("staffId");

        if (staffId == null) {
            response.sendRedirect("Login.jsp");
            return;
        }

        try {
            String staffName = userDAO.getStaffNameById(staffId);
            session.setAttribute("staffName", staffName);

            int totalMovies = movieDAO.getTotalMovies();
            int totalSeatsAvailable = movieDAO.getTotalSeatsAvailable();

            session.setAttribute("totalMovies", totalMovies);
            session.setAttribute("totalSeatsAvailable", totalSeatsAvailable);

            request.getRequestDispatcher("Staff_Home.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
