package com.mts.controller;

import com.mts.model.MovieDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "UserTicketServlet", urlPatterns = {"/UserTicketServlet"})
public class UserTicketServlet extends HttpServlet {

    private MovieDAO movieDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        movieDAO = new MovieDAO(); 
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userName = (String) session.getAttribute("userName");

        if (userName == null) {
            response.sendRedirect("Login.jsp");
            return;
        }

        try {
            List<String> moviePostersBase64 = movieDAO.getMoviePostersBase64();
            session.setAttribute("moviePostersBase64", moviePostersBase64);

            request.getRequestDispatcher("User_Ticket.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Error fetching movie posters from database", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
