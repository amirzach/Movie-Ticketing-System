package com.mts.controller;

import com.mts.model.UserDAO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class RegisterServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fullName = request.getParameter("fullname");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // Validate if passwords match
        if (!password.equals(confirmPassword)) {
            request.setAttribute("errorMessage", "Passwords do not match.");
            request.getRequestDispatcher("User_NewAccount.jsp").forward(request, response);
            return;
        }

        try {
            // Check if user already exists
            if (userDAO.isUserExists(email)) {
                request.setAttribute("errorMessage", "User with this email already exists.");
                request.getRequestDispatcher("User_NewAccount.jsp").forward(request, response);
                return;
            }

            boolean isRegistered = userDAO.registerUser(fullName, email, password);
            if (isRegistered) {
                request.setAttribute("successMessage", "Registration successful! Redirecting to login page...");
                response.setHeader("Refresh", "3; URL=Login.jsp");
            } else {
                request.setAttribute("errorMessage", "Registration failed. Please try again.");
                request.getRequestDispatcher("User_NewAccount.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
