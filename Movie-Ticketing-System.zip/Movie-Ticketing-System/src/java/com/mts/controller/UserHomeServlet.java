package com.mts.controller;

import com.mts.model.MovieDAO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class UserHomeServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private MovieDAO movieDAO = new MovieDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userName = (String) session.getAttribute("userName");

        if (userName == null) {
            response.sendRedirect("Login.jsp");
            return;
        }

        try {
            List<String> moviePostersBase64 = (List<String>) session.getAttribute("moviePostersBase64");
            if (moviePostersBase64 == null) {
                moviePostersBase64 = movieDAO.getMoviePostersBase64();
                session.setAttribute("moviePostersBase64", moviePostersBase64);
            }

            List<String> newestMovieNames = (List<String>) session.getAttribute("newestMovieNames");
            if (newestMovieNames == null) {
                newestMovieNames = movieDAO.getNewestMovieNames(3); 
                session.setAttribute("newestMovieNames", newestMovieNames);
            }

            request.getRequestDispatcher("User_Home.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Error fetching data from database", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
