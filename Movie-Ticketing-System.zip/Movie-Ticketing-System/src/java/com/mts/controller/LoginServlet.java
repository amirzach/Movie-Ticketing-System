package com.mts.controller;

import com.mts.model.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

public class LoginServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userType = request.getParameter("type");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        System.out.println("Login attempt: userType=" + userType + ", username=" + username);

        try {
            boolean isValidUser;
            if ("user".equals(userType)) {
                isValidUser = userDAO.validateUser(username, password);
                System.out.println("User valid: " + isValidUser);
                if (isValidUser) {
                    HttpSession session = request.getSession();
                    session.setAttribute("userName", userDAO.getUserName(username)); 
                    response.sendRedirect("UserHomeServlet");
                } else {
                    request.setAttribute("errorMessage", "Invalid username or password.");
                    request.getRequestDispatcher("Login.jsp").forward(request, response);
                }
            } else if ("staff".equals(userType)) {
                String staffId = userDAO.validateStaff(username, password);
                isValidUser = (staffId != null);
                System.out.println("Staff valid: " + isValidUser);
                if (isValidUser) {
                    HttpSession session = request.getSession();
                    session.setAttribute("staffId", staffId);
                    response.sendRedirect("StaffHomeServlet");
                } else {
                    request.setAttribute("errorMessage", "Invalid staff ID or password.");
                    request.getRequestDispatcher("Login.jsp").forward(request, response);
                }
            } else {
                request.setAttribute("errorMessage", "Invalid user type.");
                request.getRequestDispatcher("Login.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
