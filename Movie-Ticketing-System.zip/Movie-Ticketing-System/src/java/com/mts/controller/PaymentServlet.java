package com.mts.controller;

import com.mts.model.PaymentDAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class PaymentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = Logger.getLogger(PaymentServlet.class.getName());

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String customerId = (String) session.getAttribute("customerId");
        String cardNumber = request.getParameter("cardNumber");
        String bankName = request.getParameter("bankName");

        try {
            PaymentDAO paymentDAO = new PaymentDAO();
            String paymentId = paymentDAO.generatePaymentId();
            paymentDAO.insertPayment(paymentId, customerId, cardNumber, bankName);

            request.setAttribute("paymentId", paymentId);
            request.getRequestDispatcher("/User_PaymentSuccess.jsp").forward(request, response);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database error", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error: " + e.getMessage());
        }
    }
}
