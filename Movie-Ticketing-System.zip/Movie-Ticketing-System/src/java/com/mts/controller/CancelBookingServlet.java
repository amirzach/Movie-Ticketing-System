package com.mts.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mts.model.BookingDAO;

public class CancelBookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = Logger.getLogger(CancelBookingServlet.class.getName());

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String bookingId = request.getParameter("bookingId");
        String billId = request.getParameter("billId");

        try {
            BookingDAO bookingDAO = new BookingDAO();
            bookingDAO.deleteBooking(bookingId);
            bookingDAO.deleteBill(billId);
            response.sendRedirect("User_Booking.jsp");
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL Exception", e);
            response.sendRedirect("User_Booking.jsp");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception", e);
            response.sendRedirect("User_Booking.jsp");
        }
    }
}
